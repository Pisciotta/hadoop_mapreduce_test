package examples;
import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Job;

public class CensusCSV {
    public class TransformMapper extends Mapper<LongWritable,Text,NullWritable,Text>
    
    {
        //private static final int MISSING = 9999;
                        
        public void map(LongWritable key,Text value,Context context)
        throws IOException, InterruptedException 
    {

            String line = value.toString();
            String[] tokens = value.toString().split("\t");
                      
            String IdEduCountry = tokens[0]+","+tokens[2]+","+tokens[6];
                 
            context.write(NullWritable.get(),new Text(IdEduCountry));        
        }
    }
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = new Job(conf,"MyCSV job");    
        job.setJarByClass(CensusCSV.class);
        job.setJobName("CSV creation");
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setMapperClass(TransformMapper.class);

        job.setNumReduceTasks(0);
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(Text.class);
        
        System.exit(job.waitForCompletion(true) ? 0 : 1);
        }
}